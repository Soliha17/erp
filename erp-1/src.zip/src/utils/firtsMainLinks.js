export const linksOfMainFirts = [
  {
    id: 1,
    text: "Договора",
    to: "",
  },
  {
    id: 2,
    text: "Счет фактуры",
    to: "/third",
  },
  {
    id: 3,
    text: "Акт",
    to: "",
  },
  {
    id: 4,
    text: "Доверенность",
    to: "",
  },
  {
    id: 5,
    text: "TTH",
    to: "",
  },
];
